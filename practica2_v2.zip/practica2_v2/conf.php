<?php 
	include_once('usuario.php');

 	define('LBL_NOMBRE' , 'Nombre:');
 	define('LBL_APELLIDOS', 'Apellidos:');
 	define('LBL_FECHA_NACIMIENTO', 'Fecha de Nacimiento:');
 	define('LBL_CIUDAD_NACIMIENTO','Ciudad de Nacimiento:');
 	define('LBL_SEXO','Sexo:');
 	define('LBL_H','Hombre');
 	define('LBL_M','Mujer');
 	define('LBL_AFICIONES','Aficiones:');
 	define('LBL_DEPORTE','Deporte');
 	define('LBL_TEATRO','Teatro');
 	define('LBL_CINE','Cine');
 	define('LBL_BARES','Bares');
 	define('LBL_FOTO', 'Foto:');
 	define('LBL_FECHA_REGISTRO','Fecha de Registro:');

	include_once('cabecera.php');
 ?>