<?php 
    /*  fichero existente */
    $archivo = 'ficheros/datos.txt'; 
    if(file_exists($archivo)) { 
        $file = fopen($archivo,'r'); 
        /* mientras el puntero del fichero no esta al final */
        while(!feof($file)) {  
        	/* obtengo una linea desde el puntero */
            $name = fgets($file); 
            /* Todas las lineas quedan almacenadas en $lineas */
            $lineas[] = $name; 
        }
        /* ciere del puntero al archivo */ 
        fclose($file);
       /**
        *	Ahora elimino la fila pasada (empezamos por la 0) 
        */
        unset($lineas[$_GET['linea']]); 
       /* devuelve todos los valores del array e indexa numéricamente el array. */
        $lineas = array_values($lineas); 

        /* abro el archivo en modo escritura */
        $file = fopen($archivo, "w");
        /* recorro las lineas eliminando la linea */
        foreach( $lineas as $linea ) {
            fwrite($file,$linea); 
        } 
        /* ciere del puntero al archivo */ 
        fclose($file);      
    }
/* despues de borrar le redireciono a la pagina principal del back-end */
    header('location:admin.php');

 ?>