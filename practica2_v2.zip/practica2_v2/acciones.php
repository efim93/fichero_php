<?php 

require_once('conf.php');

		 /* variables */
		$n=0;
		$registro;
		$e=' ';
		$t=' ';

		/* fichero selecionado */
		$lineas = file('ficheros/datos.txt');
		/* Recorro el array, mostrar el código fuente HTML como tal y mostrar tambíen los números de línea.*/
		foreach ($lineas as $num_linea => $linea) {
			if($num_linea==$_GET['lineaS']){
				$num_linea++;
   			$e.="<p>Línea del fichero: #<b>{$num_linea}</b> : " .$linea."</p>";
   			$registro=$linea;
   			$n=$num_linea-1;
   			}
		}
		/*
			guardo los valores en el array contenido hacendo un explode...
		*/
		$contenido=explode(',',$registro);

/* recorido del array contenido y almaceno los casos en una variable t que contiene toda la información estructura de datos */
	 for($i=0;$i<count($contenido);$i++){  
		switch ($i) {
		    case 0:
		    	$t.="<tr><th>".LBL_NOMBRE."</th><td>".$contenido[$i]."</td></tr>";
		        break;
		    case 1:
		        $t.="<tr><th>".LBL_APELLIDOS."</th><td>".$contenido[$i]."</td></tr>";
		        break;
		    case 2:
		         $t.="<tr><th>".LBL_FECHA_NACIMIENTO."</th><td>".$contenido[$i]."</td></tr>";
		        break;
		    case 3:
		        $t.="<tr><th>".LBL_CIUDAD_NACIMIENTO."</th><td>".$contenido[$i]."</td></tr>";
		        break;
		    case 4:
		         $t.="<tr><th>".LBL_SEXO."</th><td>".$contenido[$i]."</td></tr>";
		        break;
		    case 5:
		        $t.="<tr><th>".LBL_AFICIONES."</th><td>".$contenido[$i]."</td></tr>";
		        break;
		    case 6:
		        $t.="<tr><th>".LBL_FOTO."</th><td>".$contenido[$i]."</td></tr>";
		        break;
		    case 7:
		        $t.="<tr><th>".LBL_FECHA_REGISTRO."</th><td>".$contenido[$i]."</td></tr>";
		        break;
		}
	}
	 
 ?>
 <main>
	<section>
		<h3>Datos del Registro selecionado</h3>
		<?=$e;?>
		<a href="admin.php" title="admin.php"><i class="fas fa-arrow-left fa-2x"></i></a>
		<br />
		<a href="borrar.php?linea=<?=$n?>" class="centrado"><i class="far fa-trash-alt fa-3x"></i></a>
		<br />
		<table class="centrado">
			<?=$t?>
		</table>	
	</section>
</main>
<?php include_once('pie.php'); ?>