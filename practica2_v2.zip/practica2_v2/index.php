<?php
require_once('conf.php');
?>
<body>
	<header>
		<h1>Bienvenido a inicio de aplicación</h1>
	</header>
<main>
	<section>
		<h2>Elige una opción</h2>
		<div class="aliniacionInicio">
			<a type="submit" href="formulario.php" name="frontend" class="butonrojo" >ir a Front-end</a>
			<a type="submit" href="admin.php" name="backend" class="butonazul">ir a Back-end</a>
		</div>
	</section>
</main>
<?php include_once('pie.php'); ?>