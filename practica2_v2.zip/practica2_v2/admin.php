<?php
include_once('conf.php');
	 /* variable */
	$contenido;
	$cosas=' ';
		/*	fichero existente */
	$fichero="ficheros/datos.txt";
		/* compruebo si existe el fichero y si no esta vacio  */
	if(file_exists($fichero) && (filesize($fichero)!=0)) { 
		/* creo un puntero de lectura al fichero */
	$fp=fopen($fichero,"r");
		/* almacieno los datos de la lectura del fichero */
	$datos = fread($fp, filesize($fichero));
		/* registro almacena los datos de cada registro	*/
	$registro=explode('/',$datos);
		/* libero la posición */
	unset($registro[count($registro)-1]);
		/* almacieno cada valor del registro en un array contenido  */
	for($i=0;$i<count($registro);$i++){
		$contenido[]=explode(',',$registro[$i]);
	}
		/* recorro el aray del contenido y estructuro los datos en una variable datos	*/
		for($i=0;$i<count($contenido);$i++){ 
					$cosas.="<tr>";    
			for($j=0;$j<count($contenido[$i]);$j++){ 
					$cosas.=($j<2)?"<td>".$contenido[$i][$j]."</td>":' ';
				} 
			$cosas.="<td><a href='acciones.php?lineaS=$i'><i class='far fa-plus-square fa-2x'></i></a></td></tr>"; 
		} 
	} 
?>
<body>
	<header>
		<h1>Bienvenido a Back-end</h1>
		<a href="index.php" title="index.php" ><i class="fas fa-arrow-left fa-2x"></i></a>
	</header>
<main>
	<section>
		<h3>Datos de los usuarios registrados</h3>
		<div class="centrado">
		<table>
			<thead>
			<th><?=LBL_NOMBRE ?></th>
			<th><?=LBL_APELLIDOS ?></th>
			<th></th>
			</thead>
			<tbody>
			<?=$cosas ?>
			</tbody>
		</table>
		</div>
		<div class="centrado">
			<br>
			<a href="formulario.php" id="husuario">Añadir Usuario</a>
		</div>
		</section>
</main>
<?php require_once('pie.php'); ?>