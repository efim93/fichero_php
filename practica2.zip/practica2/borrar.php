<?php 

    $archivo = 'datos.txt'; 
    if(file_exists($archivo)) { 
        $file = fopen($archivo,'r'); 
        /* mientras el puntero del fichero no esta al final */
        while(!feof($file)) {  
        	/* obtengo una linea desde el puntero */
            $name = fgets($file); 
            /* Todas las lineas quedan almacenadas en $lineas */
            $lineas[] = $name; 
        } 
        fclose($file);

       /**
        *	Ahora elimino la fila pasada (empezamos por la 0) 
        */
        unset($lineas[$_GET['linea']]); 
       /* devuelve todos los valores del array e indexa numéricamente el array. */
        $lineas = array_values($lineas); 

        /* abro el archivo en modo escritura */
        $file = fopen($archivo, "w");
        /* recorro las lineas eliminando la linea */
        foreach( $lineas as $linea ) {

            fwrite($file,$linea); 
        } 
        fclose($file);      
    }

    header('location:admin.php');

 ?>