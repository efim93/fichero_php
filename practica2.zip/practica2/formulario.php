<?php
require_once('conf.php');
require_once('cabecera.php');
?>
<body>
	<header>
		<h1>Bienvenido a Front-end</h1>
	</header>
<main>
	<section>
		<h3>Rellene formulario</h3>
		<div class="formulario">
			<form enctype="multipart/form-data" action="contenido.php" method="post">
				<label><?=LBL_NOMBRE ?></label>
				<input type="text" name="nombre" id="nombre" required="required" />
				<br />
				<label><?=LBL_APELLIDOS ?></label>
				<input type="text" name="apellidos" id="apellidos" required="required" />
				<br />
				<label><?=LBL_FECHA_NACIMIENTO ?></label>
				<input type="date" name="fechaNacimiento" id="fechaNacimiento" required="required" />
				<br />
				<label><?=LBL_CIUDAD_NACIMIENTO ?></label>
				<input type="text" name="ciudad" id="ciudad" required="required" />
				<br />
				<label><?=LBL_SEXO ?></label>
				<input type="radio" name="sexo" value="H" required="required" /><label><?=LBL_H ?></label>
				<input type="radio" name="sexo" value="M" required="required" /><label><?=LBL_M ?></label>
				<br /><br />
				<label class="conmargin"><?=LBL_AFICIONES ?></label>
				<br />
				<input type="checkbox" name="aficciones[]" class="conmargin" value="deporte" />
				<label><?=LBL_DEPORTE ?></label>
				<input type="checkbox" name="aficciones[]" class="conmargin" value="teatro" />
				<label><?=LBL_TEATRO ?></label>
				<input type="checkbox" name="aficciones[]" class="conmargin" value="cine" />
				<label><?=LBL_CINE ?></label>
				<input type="checkbox" name="aficciones[]" class="conmargin" value="bares" />
				<label><?=LBL_BARES ?></label>
				<br />
				<label><?=LBL_FOTO ?></label>
				<input type="file" name="foto" id="foto" required="required" />
				<br />
				<input type="submit" value="Enviar Datos" class="butonrojo" />
			</form>
		</div>
	</section>
</main>
<?php include_once('pie.php'); ?>