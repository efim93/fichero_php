<?php
include_once('conf.php');
include_once('cabecera.php');
include_once('usuario.php');

$fichero="datos.txt";
if(file_exists($fichero) && (filesize($fichero)!=0)) { 

$fp=fopen($fichero,"r");

$datos = fread($fp, filesize($fichero));

$registro=explode('/',$datos);

unset($registro[count($registro)-1]);


$contenido;
for($i=0;$i<count($registro);$i++){
	$contenido[]=explode(',',$registro[$i]);
}

?>
<body>
	<header>
		<h1>Bienvenido a Back-end</h1>
		<a href="index.php" title="index.php" ><i class="fas fa-arrow-left fa-2x"></i></a>
	</header>
<main>
	<section>
		<h3>Datos de los usuarios registrados</h3>
		<div class="centrado">
		<table>
			<thead>
			<th><?=LBL_NOMBRE ?></th>
			<th><?=LBL_APELLIDOS ?></th>
			<th></th>
			</thead>
			<tbody>
			<?php  for($i=0;$i<count($contenido);$i++){ 
						echo "<tr>";    
					for($j=0;$j<count($contenido[$i]);$j++){ 
						echo ($j<2)?"<td>".$contenido[$i][$j]."</td>":' ';
						 }   
			?>
		<td><a href="acciones.php?lineaS=<?=$i ?>"><i class="far fa-plus-square fa-2x"></i></a></td>
		</tr>
			<?php } } else{ ?>

			<h4>Fichero no existe o esta vacio</h4>
		<?php }	?>	
			</tbody>
		</table>
		</div>
		<div class="centrado">
			<br>
			<a href="formulario.php" id="husuario">Añadir Usuario</a>
		</div>
		</section>
</main>
<?php require_once('pie.php'); ?>