<?php 
	/**
	 * clase que registra un usuario con los datos recopilados en el formulario front-end
	 */
	class Usuario{
		
		private $nombre;
		private $apellidos;
		private $fechaNacimiento;
        private $ciudad;
        private $sexo;
        private $aficciones;
		private $foto;
        private $fechaRegistro;

     /**
     * Class Constructor
     * @param    $nombre   
     * @param    $apellidos   
     * @param    $fechaNacimiento   
     * @param    $ciudad
     * @param    $sexo
     * @param    $aficiones
     * @param    $foto
     */
    public function __construct($nombre=' ', $apellidos=' ', $fechaNacimiento=' ', $ciudad=' ',$sexo=' ',$aficciones=' ', $foto=' '){
        $this->setNombre($nombre);
        $this->setApellidos($apellidos);
        $this->setFechaNacimiento($fechaNacimiento);
        $this->setCiudad($ciudad);
        $this->setSexo($sexo);
        $this->setAficciones($aficciones);
        $this->setFoto($foto);
    }
    
    /**
     *  Metodo que me fija los datos que me pasan es como segundo constructor 
     */
    public function fijarDatos($datos,$foto){
        $this->setNombre($datos['nombre']);
        $this->setApellidos($datos['apellidos']);
        $this->setFechaNacimiento($datos['fechaNacimiento']);
        $this->setCiudad($datos['ciudad']); 
        $this->setSexo($datos['sexo']);             
        $this->setAficciones(isset($datos['aficciones'])?implode(';',$datos['aficciones']):'-');
        $this->setFoto(isset($foto)?$foto:' ');
        $this->setFechaRegistro();

    }
    /**
     * @param mixed $nombre
     */
    public function setNombre($nombre){
        $this->nombre = $nombre;
    }
	
    /**
     * @return mixed
     */
    public function getNombre(){
        return $this->nombre;
    }

    /**
     * @param mixed $apellidos
     */
    public function setApellidos($apellidos){
        $this->apellidos = $apellidos;
    }

    /**
     * @return mixed
     */
    public function getApellidos(){
        return $this->apellidos;
    }

    /**
     * @param mixed $fechaNacimiento
     */
    public function setFechaNacimiento($fechaNacimiento){
        $this->fechaNacimiento = $fechaNacimiento;
    }

    /**
     * @return mixed
     */
    public function getSexo(){
        return $this->sexo;
    }

    /**
     * @param mixed $sexo
     */
    public function setSexo($sexo){
        $this->sexo = $sexo;
    }

    /**
     * @return mixed
     */
    public function getCiudad()
    {
        return $this->ciudad;
    }

    /**
     * @param mixed $ciudad
     *
     */
    public function setCiudad($ciudad){
        $this->ciudad = $ciudad;
    }

    /**
     * @return mixed
     */
    public function getAficciones()
    {
        return $this->aficciones;
    }

    /**
     * @param mixed $aficciones
     */
    public function setAficciones($aficciones){
        $this->aficciones = $aficciones;
    }

    /**
     * Metodo que cambia la fecha segun un formato:
     * en este caso de 'aaaa-mm-dd' a 'dd-mm-aaaa',
     * en caso contrario la deja como esta.
     * @return $fechaNacimiento
     */
    public function getFechaNacimiento($formato=''){
         return   $formato?date($formato,strtotime($this->fechaNacimiento)):$this->fechaNacimiento;
    }

    /**
     * @param mixed $foto
     *
     */
    public function setFoto($foto){
        $this->foto = $foto;
    }
    /**
     * @return mixed
     */
    public function getFoto(){
        return $this->foto;
    }
    
   /**
     * @return mixed
     */
    public function getFechaRegistro($formato=''){
        return   $formato?date($formato,strtotime($this->fechaRegistro)):$this->fechaRegistro;
    }

    /**
     * metodo que me autogenera una fecha de registo de cada usuario
     * @param mixed $fechaRegistro
     */
    public function setFechaRegistro(){
        $f=new DateTime();
    foreach($f as $key => $value) {
        $fechaR=$value;
        if ($key=='date'){
        $this->fechaRegistro = $fechaR;
            return;
            }
        }
    }


    public function __toString(){
        return $this->getNombre().','.$this->getApellidos().','.$this->getFechaNacimiento('d-m-Y').','.$this->getCiudad().','.$this->getSexo().','.$this->getAficciones().','.$this->getFoto().','.$this->getFechaRegistro('d-m-Y');
    }
}
 ?>