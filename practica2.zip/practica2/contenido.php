<?php

require_once('conf.php');
include_once('cabecera.php');
require_once('usuario.php');

	 /* objeto de la clase usuario */
$u=new Usuario();
		/* establesco los datos al objeto pasandole el $_POST y nombre del fichero */
$u->fijarDatos($_POST,$_FILES['foto']['name']);

		/* recuperacion de los datos... */
	$nombre=$u->getNombre();
	$apellidos=$u->getApellidos();
		/* recupero la fecha pasandole un formato */
	$fechaNacimiento=$u->getFechaNacimiento('d-m-Y');
	$ciudad=$u->getCiudad();
	$sexo=$u->getSexo();
	$aficciones=$u->getAficciones();
	$foto=$u->getFoto();

	/* guardo el fichero de la foto */
	$fichero_subido = 'descargas/'. basename($foto);

		if ( ( ($_FILES["foto"]["type"] == "image/gif")||($_FILES["foto"]["type"] == "image/jpeg")
		||($_FILES["foto"]["type"] == "image/jpg")|| ($_FILES["foto"]["type"] == "image/JPG")
		||($_FILES["foto"]["type"] == "image/pjpeg") )&&($_FILES["foto"]["size"] < 1000000)) {
			move_uploaded_file($_FILES["foto"]["tmp_name"], "descargas/" . $foto); 
	}
	/** 
	 * accedo al informacion del objeto y concateno todo en una variable con un delimitador y salto * de liniea. 
	 */
	$cadena=$u->__toString().'/'."\n";

	/* creo un puntero al fichero en modo de escritura */
	$fp=fopen("datos.txt","a");

	/**
	 * Funcion que me crea el nuevo fichero con contenido de la cadena en fichero
	 */
	function flujo_fwrite($fp, $cadena) {
	    for ($escrito = 0; $escrito < strlen($cadena); $escrito += $fwrite) {
	        $fwrite = fwrite($fp, substr($cadena, $escrito));
	        if ($fwrite === false) {
	            return $escrito;
	        }
	    }
	    return $escrito;
	}
/* llamada a la funcion anterior */	
flujo_fwrite($fp,$cadena);
/* ciere del puntero del fichero */
fclose($fp);
?>
<body>
	<header>
		<h1>Felicidades aqui esta tu contenido</h1>
	</header>
<main>
	<section>
		<h3>Tus Datos introducidos son</h3>
		<label><?=LBL_NOMBRE ?></label>
		<label><?=$nombre ?></label>
		<label><?=LBL_APELLIDOS ?></label>
		<label><?=$apellidos ?></label>
		<label><?=LBL_FECHA_NACIMIENTO ?></label>
		<label><?=$fechaNacimiento ?></label>
		<label><?=LBL_CIUDAD_NACIMIENTO ?></label>
		<label><?=$ciudad ?></label>
		<label><?=LBL_SEXO ?></label>
		<label><?=$sexo ?></label>
		<label><?=LBL_AFICIONES ?></label>
		<label><?=$aficciones ?></label>
		<label><?=LBL_FOTO ?></label>
		<label><?=$foto ?></label>
	</section>
</main>
<?php include_once('pie.php'); ?>